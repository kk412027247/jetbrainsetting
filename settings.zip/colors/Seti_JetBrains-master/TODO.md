# TODO
- [x] Remove the gutter color and see how it looks.
- [x] Can't we change the main app theme colors ?
- [ ] The numbers should be in red like the (-1) to make it easier to spot.
- [ ] Give the var a different color other than white to make it more distinguishable.
- [ ] Proceed with the respective icon change
