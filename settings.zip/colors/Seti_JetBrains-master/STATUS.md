# Status
Language/Section | Syntax Supported | Icon Supported | Note
---|---|---|---
Java | No | **Yes** | -
ActionScript | No | No | -
CFML | No | No | -
CoffeeScript | No | **Yes** | -
CSS | __*WIP*__ | **Yes** | -
Gherkin| No | No | -
Groovy | No | No | -
GSP | No | No | -
HAML | No | **Yes** | -
HTML | __*WIP*__ | **Yes** | -
Jade | No | No | -
JavaScript | __*WIP*__ | **Yes** | -
JSON | No | No | -
JSP| No | No | -
JSPX | No | No | -
LESS | No | No | -
PHP | No | **Yes** | -
Python | No | No | -
Ruby | __*WIP*__ | **Yes** | -
SASS | __*WIP*__ | **Yes** | -
SCSS | __*WIP*__ | **Yes** | -
Slim | No | No | -
SQL | No | No | -
Stylus | No | No | -
TypeScript | No | No | -
Velocity | No | No | -
XML | No | No | -
Yaml | No | No | -
