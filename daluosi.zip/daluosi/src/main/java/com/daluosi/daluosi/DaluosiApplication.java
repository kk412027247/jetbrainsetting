package com.daluosi.daluosi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DaluosiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DaluosiApplication.class, args);
	}

}
